from django.apps import AppConfig


class OrdersappConfig(AppConfig):
    name = 'ordersapp'
