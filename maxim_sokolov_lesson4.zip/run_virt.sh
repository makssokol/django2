#!/usr/bin/env bash
source ~/django2/django2/bin/activate
