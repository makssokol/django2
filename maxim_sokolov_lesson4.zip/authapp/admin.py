from django.contrib import admin
from .models import ArtShopUser

admin.site.register(ArtShopUser)